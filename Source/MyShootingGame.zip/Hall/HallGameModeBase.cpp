//// Fill out your copyright notice in the Description page of Project Settings.
//
//
//#include "MyShootingGame/Hall/HallGameModeBase.h"
//#include "HallPawn.h"
//#include "MyShootingGame/Hall/HallHUD.h"
//#include "MyShootingGame/Hall/HallPlayerController.h"
//
//AHallGameModeBase::AHallGameModeBase()
//{
//		static ConstructorHelpers::FClassFinder<AHallPawn> BPHallPawnClass(TEXT("/Game/_Game/BP/Hall/BP_HallPawn"));
//		if (BPHallPawnClass.Class)
//		{
//			DefaultPawnClass = BPHallPawnClass.Class;
//		}
//		HUDClass = AHallHUD::StaticClass();
//		PlayerControllerClass = AHallPlayerController::StaticClass();
//}
