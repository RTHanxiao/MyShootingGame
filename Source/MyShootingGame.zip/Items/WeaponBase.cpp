//// Fill out your copyright notice in the Description page of Project Settings.
//
//
//#include "MyShootingGame/Items/WeaponBase.h"
//#include "Components/SkeletalMeshComponent.h"
//#include "Components/SphereComponent.h"
//#include "Components/SceneComponent.h"
//#include "../Character/PlayerCharacter.h"
//#include "../Logic/MSG_EventManager.h"
//#include "Kismet/GameplayStatics.h"
//#include "Blueprint/WidgetLayoutLibrary.h"
//#include "../GameCore/MSG_PlayerController.h"
//#include "PhysicalMaterials/PhysicalMaterial.h"
//#include "Kismet/KismetMathLibrary.h"
//#include "../Character/ZombieCharacter.h"
//#include "Engine/DamageEvents.h"
//#include "BulletPool.h"
//#include "Bullet.h"
//
//// Sets default values
//AWeaponBase::AWeaponBase()
//{
// 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
//	PrimaryActorTick.bCanEverTick = true;
//	
//	RootComponent = Root;
//
//	////����ʰȡ��ײ���
//	//PickCollision = CreateDefaultSubobject<USphereComponent>(TEXT("PickCollision"));
//	//PickCollision->SetupAttachment(SceneRoot);
//	//PickCollision->SetSphereRadius(150.f);
//	ItemCollision->SetSphereRadius(150.f);
//
//	//���������������
//	WeaponSkeletal = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("WeaponSkeletal"));
//	WeaponSkeletal->SetupAttachment(Root);
//
//	BulletPool = CreateDefaultSubobject<UBulletPool>(TEXT("BulletPool"));
//
//}
//
//// Called when the game starts or when spawned
//void AWeaponBase::BeginPlay()
//{
//	Super::BeginPlay();
//	
//	InitWeaponData();
//
//	//����ײʰȡ�¼�
//	//PickCollision->OnComponentBeginOverlap.AddDynamic(this, &AWeaponBase::AttachGunToHand);
//
//	VerticalRecoil = WeaponStruct->RecoilPitch;
//	HorizontalRecoil = WeaponStruct->RecoilYaw;
//}
//
//void AWeaponBase::OnEnterInteractRange(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
//{
//	if (APlayerCharacter* Player = Cast<APlayerCharacter>(OtherActor))
//	{
//		// ���ฺ��PickWidget ��ʾ + Outline ���أ������ڻ���ʵ���ˣ�
//		Super::OnEnterInteractRange(OverlappedComponent, OtherActor, OtherComp, OtherBodyIndex, bFromSweep, SweepResult);
//
//		// ������⣺�Զ���������
//		if (WeaponSkeletal)
//		{
//			WeaponSkeletal->bRenderCustomDepth = true;
//		}
//	}
//}
//
//void AWeaponBase::OnLeaveInteractRange(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
//{
//	if (APlayerCharacter* Player = Cast<APlayerCharacter>(OtherActor))
//	{
//		if (Player->PickItem == this)
//		{
//			Player->PickItem = nullptr;
//		}
//
//		// PickWidget ���� + Outline �ر�
//		Super::OnLeaveInteractRange(OverlappedComponent, OtherActor, OtherComp, OtherBodyIndex);
//
//		// ������⣺�ر��Զ���������
//		if (ItemMesh)
//		{
//			ItemMesh->bRenderCustomDepth = false;
//		}
//	}
//}
//
//// Called every frame
//void AWeaponBase::Tick(float DeltaTime)
//{
//	Super::Tick(DeltaTime);
//
//}
//
//void AWeaponBase::InitWeaponData()
//{
//	WeaponData = LoadObject<UDataTable>(nullptr, TEXT("/Game/_Game/Data/DT_Weapon"));
//	WeaponStruct = WeaponData->FindRow<FWeaponTemplateStructure>(WeaponRowName, TEXT(""));
//	WeaponSkeletal->SetSkeletalMeshAsset(WeaponStruct->WeaponSkeletal);
//	CurrentAmmoInMag = WeaponStruct->MagazineSize;
//	TotalAmmo = WeaponStruct->Ammo;
//}
//
//void AWeaponBase::AttachGunToHand(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
//{
//	if (APlayerCharacter* Player = Cast<APlayerCharacter>(OtherActor)) 
//	{
//		Player->PickUpWeapon(this);
//	}
//}
//
////���߼��
////void AWeaponBase::ShootEvent()
////{
////	//���ٵ�ϻ���ӵ���
////	CurrentAmmoInMag--;
////
////	//���ſ��𶯻�
////	UAnimationAsset* WeaponShootAnim = WeaponStruct->FireAnimation;
////	if (WeaponShootAnim)
////	{
////		WeaponSkeletal->PlayAnimation(WeaponShootAnim, false);
////	}
////
////	//�յ�������
////	SpawnShellEject();
////
////	//����������ֹ
////	FVector StartVector;
////	FVector WorldDir;
////	FVector2D ScreenPos = UWidgetLayoutLibrary::GetViewportSize(GetWorld()) * 0.5;
////	if (AMSG_PlayerController* PC = Cast<AMSG_PlayerController>(WeaponOwner->GetController()))
////	{
////		UGameplayStatics::DeprojectScreenToWorld(PC, ScreenPos, StartVector, WorldDir);
////	}
////	FVector EndVector = (WorldDir * 10000.f) + StartVector;
////
////	TArray<TEnumAsByte<EObjectTypeQuery>> ObjectType;
////	ObjectType.Add(EObjectTypeQuery::ObjectTypeQuery1);
////	ObjectType.Add(EObjectTypeQuery::ObjectTypeQuery3);
////
////	//���Ե�Actror
////	TArray<AActor*> IgnoreActors;
////
////	//����debug��
////	//EDrawDebugTrace::Type DrawDebugType = EDrawDebugTrace::Persistent;
////	EDrawDebugTrace::Type DrawDebugType = EDrawDebugTrace::None;
////
////	FHitResult HitResult;
////	//��������
////	UKismetSystemLibrary::LineTraceSingleForObjects(GetWorld(), StartVector, EndVector, ObjectType, false, IgnoreActors, DrawDebugType, HitResult, true);
////
////	UPhysicalMaterial* HistPhysicalMaterial = HitResult.PhysMaterial.Get();
////	AActor* HitActor = HitResult.GetActor();
////	
////	FRotator BulletSpawnRotation = FRotator::ZeroRotator;
////	if (HitResult.bBlockingHit)
////	{
////		BulletSpawnRotation = UKismetMathLibrary::Conv_VectorToRotator(HitResult.Location - WeaponSkeletal->GetSocketLocation("MUZZLE"));
////	}
////	else
////	{
////		BulletSpawnRotation = UKismetMathLibrary::Conv_VectorToRotator(HitResult.TraceEnd - WeaponSkeletal->GetSocketLocation("MUZZLE"));
////	}
////	//�ӵ�������
////	if (ABullet* Bullet = BulletPool->GetBullet())
////	{
////		FVector MuzzleLocation = WeaponSkeletal->GetSocketLocation("MUZZLE");
////		FRotator MuzzleRotation = WeaponSkeletal->GetSocketRotation("MUZZLE");
////
////		Bullet->ActivateBullet(MuzzleLocation, BulletSpawnRotation, 5000.f);
////	}
////
////	//�˺�����
////	if (AZombieCharacter* Zombie = Cast<AZombieCharacter>(HitResult.GetActor()))
////	{ 
////		if (AMSG_PlayerController* PC = Cast<AMSG_PlayerController>(WeaponOwner->GetController()))
////		{
////			float Damage = WeaponStruct->AttackDamage;
////			bool bHeadShot = false;
////			//�ж��ܻ���λ���˺�=�����˺�*��λ����*����ϵ��
////			switch (HistPhysicalMaterial->SurfaceType)
////			{
////			case EPhysicalSurface::SurfaceType7:
////				Damage *= WeaponStruct->HeadshotMultiplier;
////				bHeadShot = true;
////				break;
////			case EPhysicalSurface::SurfaceType8:
////				Damage *= WeaponStruct->ArmMultiplier;				
////				break;
////			case EPhysicalSurface::SurfaceType9:
////				Damage *= WeaponStruct->LegMultiplier;				
////				break;
////			case EPhysicalSurface::SurfaceType10:
////				Damage *= WeaponStruct->ChestMultiplier;
////				break;
////			case EPhysicalSurface::SurfaceType11:
////				Damage *= WeaponStruct->AbsMultiplier;
////				break;
////			default:
////				break;
////			}
////			//Ӧ�ü���ϵ��
////			Damage *= Zombie->DamageReductionFactor;
////
////			//����˺�
////			Zombie->TakeDamage(Damage, FDamageEvent(), PC, this);
////
////			bool bDead = Zombie->IsDead();
////
////			if (bDead)
////			{
////				if (bHeadShot)
////				{
////					UMSG_EventManager::GetEventManagerInstance()->ShowKillFeedbackDelegate.ExecuteIfBound(true);
////					UMSG_EventManager::GetEventManagerInstance()->HeadShotEventDelegate.ExecuteIfBound();
////					UE_LOG(LogTemp, Warning, TEXT("HeadShot Kill"));
////				}
////				else
////				{
////					UMSG_EventManager::GetEventManagerInstance()->ShowKillFeedbackDelegate.ExecuteIfBound(false);
////					UE_LOG(LogTemp, Warning, TEXT("Normal Kill"));
////				}
////			}
////			else
////			{
////				UMSG_EventManager::GetEventManagerInstance()->ShowHitFeedbackDelegate.ExecuteIfBound(bHeadShot);
////				UE_LOG(LogTemp, Warning, TEXT("Hit Zombie %s"), bHeadShot ? TEXT("HeadShot") : TEXT("Body"));
////			}
////
////			//����ѪҺ��Ч
////			UGameplayStatics::SpawnEmitterAtLocation(
////				GetWorld(), 
////				FleshParticle, 
////				HitResult.Location, 
////				UKismetMathLibrary::Conv_VectorToRotator(HitResult.Normal), 
////				FVector(.5f, .5f, .5f));
////		}
////	}
////
////	if (HistPhysicalMaterial)
////	{
////		FVector SpawnParticleLocation = HitResult.Location;
////		FRotator SpawnParticleRotation = UKismetMathLibrary::Conv_VectorToRotator(HitResult.Normal);
////		FVector SpawnParticleScale = FVector(.5f, .5f, .5f);
////		switch (HistPhysicalMaterial->SurfaceType)
////		{
////			case EPhysicalSurface::SurfaceType1:
////				UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), DirtParticle, SpawnParticleLocation, SpawnParticleRotation, SpawnParticleScale);
////				UGameplayStatics::PlaySoundAtLocation(GetWorld(), DirtSound, SpawnParticleLocation);
////				UGameplayStatics::SpawnDecalAtLocation(GetWorld(), BulletDecalMaterial, FVector(5.f, 5.f, 5.f), SpawnParticleLocation, SpawnParticleRotation);
////				break;
////			case EPhysicalSurface::SurfaceType2:
////				UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), GrassParticle, SpawnParticleLocation, SpawnParticleRotation, SpawnParticleScale);
////				UGameplayStatics::PlaySoundAtLocation(GetWorld(), GrassSound, SpawnParticleLocation);
////				UGameplayStatics::SpawnDecalAtLocation(GetWorld(), BulletDecalMaterial, FVector(5.f, 5.f, 5.f), SpawnParticleLocation, SpawnParticleRotation);
////				break;
////			case EPhysicalSurface::SurfaceType3:
////				UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), RockParticle, SpawnParticleLocation, SpawnParticleRotation, SpawnParticleScale);
////				UGameplayStatics::PlaySoundAtLocation(GetWorld(), RockSound, SpawnParticleLocation);
////				UGameplayStatics::SpawnDecalAtLocation(GetWorld(), BulletDecalMaterial, FVector(5.f, 5.f, 5.f), SpawnParticleLocation, SpawnParticleRotation);
////				break;
////			case EPhysicalSurface::SurfaceType4:
////				UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MetalParticle, SpawnParticleLocation, SpawnParticleRotation, SpawnParticleScale);
////				UGameplayStatics::PlaySoundAtLocation(GetWorld(), MetalSound, SpawnParticleLocation);
////				UGameplayStatics::SpawnDecalAtLocation(GetWorld(), BulletDecalMaterial, FVector(5.f, 5.f, 5.f), SpawnParticleLocation, SpawnParticleRotation);
////				break;
////			case EPhysicalSurface::SurfaceType5:
////				UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), WoodParticle, SpawnParticleLocation, SpawnParticleRotation, SpawnParticleScale);
////				UGameplayStatics::PlaySoundAtLocation(GetWorld(), WoodSound, SpawnParticleLocation);
////				UGameplayStatics::SpawnDecalAtLocation(GetWorld(), BulletDecalMaterial, FVector(5.f, 5.f, 5.f), SpawnParticleLocation, SpawnParticleRotation);
////				break;
////			case EPhysicalSurface::SurfaceType6:
////				UGameplayStatics::PlaySoundAtLocation(GetWorld(), FleshSound, SpawnParticleLocation);
////				break;
////			case EPhysicalSurface::SurfaceType7:
////				UGameplayStatics::PlaySoundAtLocation(GetWorld(), HeadShotSound, SpawnParticleLocation);
////				break;
////			case EPhysicalSurface::SurfaceType8:
////				UGameplayStatics::PlaySoundAtLocation(GetWorld(), FleshSound, SpawnParticleLocation);
////				break;
////			case EPhysicalSurface::SurfaceType9:
////				UGameplayStatics::PlaySoundAtLocation(GetWorld(), FleshSound, SpawnParticleLocation);
////				break;
////			case EPhysicalSurface::SurfaceType10:
////				UGameplayStatics::PlaySoundAtLocation(GetWorld(), FleshSound, SpawnParticleLocation);
////				break;
////			case EPhysicalSurface::SurfaceType11:
////				UGameplayStatics::PlaySoundAtLocation(GetWorld(), FleshSound, SpawnParticleLocation);
////				break;
////		default:
////			break;
////		}
////	}
////}
//
////��ײ���
//void AWeaponBase::ShootEvent()
//{
//	// 1) ���ٵ�ϻ���ӵ�����������������пյ��ٵ��� ShootEvent��
//	CurrentAmmoInMag--;
//
//	// 2) ���ſ��𶯻�
//	UAnimationAsset* WeaponShootAnim = WeaponStruct->FireAnimation;
//	if (WeaponShootAnim && WeaponSkeletal)
//	{
//		WeaponSkeletal->PlayAnimation(WeaponShootAnim, false);
//	}
//
//	// 3) �յ�������
//	SpawnShellEject();
//
//	// 4) ����׼�����е�
//	AMSG_PlayerController* PC = WeaponOwner ? Cast<AMSG_PlayerController>(WeaponOwner->GetController()) : nullptr;
//	if (!PC || !GetWorld() || !WeaponSkeletal || !BulletPool) return;
//
//	// ��Ļ���ķ�ͶӰ
//	FVector CamWorldOrigin = FVector::ZeroVector;
//	FVector CamWorldDir = FVector::ForwardVector;
//
//	int32 SizeX = 0, SizeY = 0;
//	PC->GetViewportSize(SizeX, SizeY);
//	const FVector2D ScreenCenter(SizeX * 0.5f, SizeY * 0.5f);
//
//	PC->DeprojectScreenPositionToWorld(ScreenCenter.X, ScreenCenter.Y, CamWorldOrigin, CamWorldDir);
//	CamWorldDir = CamWorldDir.GetSafeNormal();
//
//	const float TraceDistance = 100000.f; // 1000m �����
//	const FVector TraceStart = CamWorldOrigin;
//	const FVector TraceEnd = TraceStart + CamWorldDir * TraceDistance;
//
//	FHitResult AimHit;
//	FCollisionQueryParams Params(SCENE_QUERY_STAT(AimTrace), true);
//	Params.AddIgnoredActor(WeaponOwner);
//	Params.AddIgnoredActor(this); // ��������
//	
//	const bool bHit = GetWorld()->LineTraceSingleByChannel(
//		AimHit,
//		TraceStart,
//		TraceEnd,
//		ECC_GameTraceChannel1,
//		Params
//	);
//
//	// AimPoint���е��Զ��
//	const FVector AimPoint = bHit ? AimHit.ImpactPoint : TraceEnd;
//
//	// 5) ǹ�ڵ� AimPoint ������У��������ǹ���Ӳ�/�������ڵ�����ƫ��
//	FHitResult MuzzleHit;
//	FCollisionQueryParams MuzzleParams(SCENE_QUERY_STAT(MuzzleTrace), true);
//	MuzzleParams.AddIgnoredActor(WeaponOwner);
//	MuzzleParams.AddIgnoredActor(this);
//
//	const FVector MuzzleLocation = WeaponSkeletal->GetSocketLocation(TEXT("MUZZLE"));
//	const FVector MuzzleTraceStart = MuzzleLocation;
//	const FVector MuzzleTraceEnd = AimPoint; // ֻ׷�� AimPoint����׷��Զ
//
//	const bool bMuzzleHit = GetWorld()->LineTraceSingleByChannel(
//		MuzzleHit,
//		MuzzleTraceStart,
//		MuzzleTraceEnd,
//		ECC_Visibility,
//		MuzzleParams
//	);
//
//	// �����ӵ�Ӧ����׼�ĵ㣺���ǹ�ڵ� AimPoint ·�����ڵ�������׼�ڵ���
//	const FVector MuzzleAimPoint = bMuzzleHit ? MuzzleHit.ImpactPoint : AimPoint;
//
//	// ���¼��� ShootDir����У�����Ŀ��㣩
//	FVector ShootDir = (MuzzleAimPoint - MuzzleLocation).GetSafeNormal();
//	if (ShootDir.IsNearlyZero())
//	{
//		ShootDir = CamWorldDir;
//	}
//
//	// �ӵ�������ǰ�ƣ�����һ������ײ�����/ǹ
//	const float MuzzleForwardOffset = 20.f;
//	const FVector BulletSpawnLoc = MuzzleLocation + ShootDir * MuzzleForwardOffset;
//
//
//
//	// 6) �����ӵ����� Bullet �� OnHit ����ʵ���з���/�˺���
//	if (ABullet* Bullet = BulletPool->GetBullet())
//	{
//		// ���ӵ����� Owner������ IgnoreActorWhenMoving ��Ч
//		Bullet->SetOwner(WeaponOwner);
//
//		const float BulletSpeed = 5000.f; 
//		Bullet->ActivateBullet(BulletSpawnLoc, ShootDir.Rotation(), BulletSpeed, this);
//	}
//}
//
//UParticleSystem* AWeaponBase::GetShellEffect() 
//{
//	if (WeaponStruct && WeaponStruct->WeaponShell)
//	{
//		return WeaponStruct->WeaponShell;
//	}
//	return nullptr;
//}
//
//void AWeaponBase::Reload()
//{
//	//������Ҫ������ӵ���
//	int32 AmmoNeeded = WeaponStruct->MagazineSize - CurrentAmmoInMag;
//	if (TotalAmmo >= AmmoNeeded)
//	{
//		CurrentAmmoInMag += AmmoNeeded;
//		TotalAmmo -= AmmoNeeded;
//	}
//	else
//	{
//		CurrentAmmoInMag += TotalAmmo;
//		TotalAmmo = 0;
//	}
//}
//
//void AWeaponBase::PlayReloadMontage()
//{
//	//����̫���������������һ����̫��
//
//	if (ReloadMontages.Num() == 0) return;
//	int32 RandomIndex = UKismetMathLibrary::RandomInteger(ReloadMontages.Num() - 1);
//
//	UAnimationAsset* SelectedMontage = ReloadMontages[RandomIndex];
//
//	// �����̫���Ƿ���Ч
//	if (!SelectedMontage)
//	{
//		UE_LOG(LogTemp, Warning, TEXT("Selected reload montage is null at index %d"), RandomIndex);
//		return;
//	}
//
//	// ������̫��
//	if (WeaponSkeletal->GetAnimInstance())
//	{
//		WeaponSkeletal->PlayAnimation(SelectedMontage,false);
//
//		UE_LOG(LogTemp, Log, TEXT("Playing reload montage: %s"), *SelectedMontage->GetName());
//	}
//	else
//	{
//		UE_LOG(LogTemp, Warning, TEXT("Weapon anim instance not found!"));
//	}
//
//}
//
//void AWeaponBase::HandleBulletHit(const FHitResult& Hit)
//{
//	UPhysicalMaterial* HistPhysicalMaterial = Hit.PhysMaterial.Get();
//	AActor* HitActor = Hit.GetActor();
//	UPrimitiveComponent* HitComp = Hit.GetComponent();
//
//	UE_LOG(LogTemp, Warning, TEXT("[Hit] Actor=%s Comp=%s Bone=%s PM=%s Surface=%d"),
//		HitActor ? *HitActor->GetName() : TEXT("None"),
//		HitComp ? *HitComp->GetName() : TEXT("None"),
//		*Hit.BoneName.ToString(),
//		HistPhysicalMaterial ? *HistPhysicalMaterial->GetName() : TEXT("None"),
//		HistPhysicalMaterial ? (int32)HistPhysicalMaterial->SurfaceType : -1
//	);
//
//	// �˺��������򵽽�ʬ����
//	if (AZombieCharacter* Zombie = Cast<AZombieCharacter>(HitActor))
//	{
//		if (AMSG_PlayerController* PC = Cast<AMSG_PlayerController>(WeaponOwner->GetController()))
//		{
//			float Damage = WeaponStruct->AttackDamage;
//			bool bHeadShot = false;
//
//			if (HistPhysicalMaterial)
//			{
//				switch (HistPhysicalMaterial->SurfaceType)
//				{
//				case EPhysicalSurface::SurfaceType7:
//					Damage *= WeaponStruct->HeadshotMultiplier;
//					bHeadShot = true;
//					break;
//				case EPhysicalSurface::SurfaceType8:
//					Damage *= WeaponStruct->ArmMultiplier;
//					break;
//				case EPhysicalSurface::SurfaceType9:
//					Damage *= WeaponStruct->LegMultiplier;
//					break;
//				case EPhysicalSurface::SurfaceType10:
//					Damage *= WeaponStruct->ChestMultiplier;
//					break;
//				case EPhysicalSurface::SurfaceType11:
//					Damage *= WeaponStruct->AbsMultiplier;
//					break;
//				default:
//					break;
//				}
//			}
//
//			Damage *= Zombie->DamageReductionFactor;
//
//			Zombie->TakeDamage(Damage, FDamageEvent(), PC, this);
//
//			const bool bDead = Zombie->IsDead();
//
//			if (bDead)
//			{
//				if (bHeadShot)
//				{
//					UMSG_EventManager::GetEventManagerInstance()->ShowKillFeedbackDelegate.ExecuteIfBound(true);
//					UMSG_EventManager::GetEventManagerInstance()->HeadShotEventDelegate.ExecuteIfBound();
//				}
//				else
//				{
//					UMSG_EventManager::GetEventManagerInstance()->ShowKillFeedbackDelegate.ExecuteIfBound(false);
//				}
//			}
//			else
//			{
//				UMSG_EventManager::GetEventManagerInstance()->ShowHitFeedbackDelegate.ExecuteIfBound(bHeadShot);
//			}
//
//			// ����ѪҺ��Ч
//			UGameplayStatics::SpawnEmitterAtLocation(
//				GetWorld(),
//				FleshParticle,
//				Hit.Location,
//				UKismetMathLibrary::Conv_VectorToRotator(Hit.Normal),
//				FVector(.5f, .5f, .5f));
//		}
//	}
//
//	// ���в��ʷ���������/����/������
//	if (HistPhysicalMaterial)
//	{
//		const FVector SpawnParticleLocation = Hit.Location;
//		const FRotator SpawnParticleRotation = UKismetMathLibrary::Conv_VectorToRotator(Hit.Normal);
//		const FVector SpawnParticleScale = FVector(.5f, .5f, .5f);
//
//		switch (HistPhysicalMaterial->SurfaceType)
//		{
//		case EPhysicalSurface::SurfaceType1:
//			UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), DirtParticle, SpawnParticleLocation, SpawnParticleRotation, SpawnParticleScale);
//			UGameplayStatics::PlaySoundAtLocation(GetWorld(), DirtSound, SpawnParticleLocation);
//			UGameplayStatics::SpawnDecalAtLocation(GetWorld(), BulletDecalMaterial, FVector(5.f, 5.f, 5.f), SpawnParticleLocation, SpawnParticleRotation);
//			break;
//		case EPhysicalSurface::SurfaceType2:
//			UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), GrassParticle, SpawnParticleLocation, SpawnParticleRotation, SpawnParticleScale);
//			UGameplayStatics::PlaySoundAtLocation(GetWorld(), GrassSound, SpawnParticleLocation);
//			UGameplayStatics::SpawnDecalAtLocation(GetWorld(), BulletDecalMaterial, FVector(5.f, 5.f, 5.f), SpawnParticleLocation, SpawnParticleRotation);
//			break;
//		case EPhysicalSurface::SurfaceType3:
//			UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), RockParticle, SpawnParticleLocation, SpawnParticleRotation, SpawnParticleScale);
//			UGameplayStatics::PlaySoundAtLocation(GetWorld(), RockSound, SpawnParticleLocation);
//			UGameplayStatics::SpawnDecalAtLocation(GetWorld(), BulletDecalMaterial, FVector(5.f, 5.f, 5.f), SpawnParticleLocation, SpawnParticleRotation);
//			break;
//		case EPhysicalSurface::SurfaceType4:
//			UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), MetalParticle, SpawnParticleLocation, SpawnParticleRotation, SpawnParticleScale);
//			UGameplayStatics::PlaySoundAtLocation(GetWorld(), MetalSound, SpawnParticleLocation);
//			UGameplayStatics::SpawnDecalAtLocation(GetWorld(), BulletDecalMaterial, FVector(5.f, 5.f, 5.f), SpawnParticleLocation, SpawnParticleRotation);
//			break;
//		case EPhysicalSurface::SurfaceType5:
//			UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), WoodParticle, SpawnParticleLocation, SpawnParticleRotation, SpawnParticleScale);
//			UGameplayStatics::PlaySoundAtLocation(GetWorld(), WoodSound, SpawnParticleLocation);
//			UGameplayStatics::SpawnDecalAtLocation(GetWorld(), BulletDecalMaterial, FVector(5.f, 5.f, 5.f), SpawnParticleLocation, SpawnParticleRotation);
//			break;
//		case EPhysicalSurface::SurfaceType6:
//			UGameplayStatics::PlaySoundAtLocation(GetWorld(), FleshSound, SpawnParticleLocation);
//			break;
//		case EPhysicalSurface::SurfaceType7:
//			UGameplayStatics::PlaySoundAtLocation(GetWorld(), HeadShotSound, SpawnParticleLocation);
//			break;
//		case EPhysicalSurface::SurfaceType8:
//		case EPhysicalSurface::SurfaceType9:
//		case EPhysicalSurface::SurfaceType10:
//		case EPhysicalSurface::SurfaceType11:
//			UGameplayStatics::PlaySoundAtLocation(GetWorld(), FleshSound, SpawnParticleLocation);
//			break;
//		default:
//			break;
//		}
//	}
//}
