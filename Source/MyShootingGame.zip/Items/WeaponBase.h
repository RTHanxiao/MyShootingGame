//// Fill out your copyright notice in the Description page of Project Settings.
//
//#pragma once
//
//#include "CoreMinimal.h"
//#include "GameFramework/Actor.h"
//#include "../Table/WeaponTemplate.h"
//#include "Particles/ParticleSystem.h"
//#include "../../../../../../../Source/Runtime/CoreUObject/Public/Templates/SubclassOf.h"
//#include "ItemBase.h"
//#include "WeaponBase.generated.h"
//
//class USceneComponent;
//class USkeletalMeshComponent;
//class USphereComponent;
//class UDataTable;
//class APlayerCharacter;
//class UParticleSystem;
//class UMaterialInterface;
//class USoundBase;
//class UBulletPool;
//
//UCLASS()
//class MYSHOOTINGGAME_API AWeaponBase : public AItemBase
//{
//	GENERATED_BODY()
//	
//public:	
//	// Sets default values for this actor's properties
//	AWeaponBase();
//
//	//UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly, Category = "Components")
//	//USceneComponent* SceneRoot;
//
//	UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly, Category = "Components")
//	USkeletalMeshComponent* WeaponSkeletal;
//
//	//UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly, Category = "Components")
//	//USphereComponent* PickCollision;
//
//	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Components")
//	UBulletPool* BulletPool;
//
//
//protected:
//	// Called when the game starts or when spawned
//	virtual void BeginPlay() override;
//
//	virtual void OnEnterInteractRange(
//		UPrimitiveComponent* OverlappedComponent,
//		AActor* OtherActor,
//		UPrimitiveComponent* OtherComp,
//		int32 OtherBodyIndex,
//		bool bFromSweep,
//		const FHitResult& SweepResult
//	) override;
//
//	virtual void OnLeaveInteractRange(
//		UPrimitiveComponent* OverlappedComponent,
//		AActor* OtherActor,
//		UPrimitiveComponent* OtherComp,
//		int32 OtherBodyIndex
//	) override;
//
//public:	
//	// Called every frame
//	virtual void Tick(float DeltaTime) override;
//
//	// ��ʼ����������
//	void InitWeaponData();
//	
//	// ��ȡ������Ч - ��ͼ�ɵ���
//	UFUNCTION(BlueprintCallable, Category = "Weapon")
//	UParticleSystem* GetShellEffect();
//
//	//���ɵ���
//	UFUNCTION(BlueprintImplementableEvent)
//	void SpawnShellEject();
//
//	UStaticMesh* GetStaticMesh() const { return WeaponStruct->WeaponMesh; }
//
//	FName GetWeaponName() const { return WeaponStruct->WeaponName; }
//
//	FText GetWeaponDescription() const { return WeaponStruct->WeaponDescription; }
//
//	UPROPERTY()
//	UDataTable* WeaponData;
//
//	FWeaponTemplateStructure*  WeaponStruct;
//
//	UPROPERTY(EditAnywhere)
//	FName WeaponRowName = FName(TEXT("AK47"));
//
//	//��ǰ��ϻ���ӵ���
//	int32 CurrentAmmoInMag;
//	//���ӵ���
//	int32 TotalAmmo;
//	//�ܷ񻻵�
//	bool CanReload() const { return CurrentAmmoInMag < WeaponStruct->MagazineSize && TotalAmmo > 0; }
//	//����
//	UFUNCTION(BlueprintCallable)
//	void Reload();
//	//ǹе������̫��
//	UPROPERTY(EditDefaultsOnly, Category = "Anim", meta = (AllowPrivateAccess = "true"))
//	TArray<UAnimationAsset*> ReloadMontages;
//	//���Ż�����̫��
//	UFUNCTION(BlueprintCallable)
//	void PlayReloadMontage();
//	//��ȡ��ϻ���ӵ���
//	UFUNCTION(BlueprintCallable, Category = "Weapon")
//	int32 GetCurrentAmmoInMag() const { return CurrentAmmoInMag; }
//	//��ȡ���ӵ���
//	UFUNCTION(BlueprintCallable, Category = "Weapon")
//	int32 GetTotalAmmo() const { return TotalAmmo; }
//	//�������ӵ���
//	void SetTotalAmmo(int32 NewTotalAmmo) { TotalAmmo = NewTotalAmmo; }
//	//���õ�ϻ���ӵ���
//	void SetCurrentAmmoInMag(int32 NewAmmoInMag) { CurrentAmmoInMag = NewAmmoInMag; }
//	//��������ص�ǰIndex
//	int32 BulletPoolIndex = 0;
//
//	//�ж��Ƿ��ܿ�ǹ
//	bool EnoughAmmo() const { return CurrentAmmoInMag > 0; }
//
//	UFUNCTION()
//	void AttachGunToHand(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
//
//	UPROPERTY()
//	APlayerCharacter* WeaponOwner = nullptr;
//
//	//����¼�
//	void ShootEvent();
//
//	//�����ӵ�����
//	void HandleBulletHit(const FHitResult& HitResult);
//
//	////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	// �����ӵ�����������������
//	UPROPERTY(EditDefaultsOnly,Category = "PhysicalParticle")
//	UParticleSystem* DirtParticle;
//	UPROPERTY(EditDefaultsOnly, Category = "PhysicalParticle")
//	UParticleSystem* GrassParticle;
//	UPROPERTY(EditDefaultsOnly, Category = "PhysicalParticle")
//	UParticleSystem* RockParticle;
//	UPROPERTY(EditDefaultsOnly, Category = "PhysicalParticle")
//	UParticleSystem* MetalParticle;
//	UPROPERTY(EditDefaultsOnly, Category = "PhysicalParticle")
//	UParticleSystem* WoodParticle;
//	UPROPERTY(EditDefaultsOnly, Category = "PhysicalParticle")
//	UParticleSystem* FleshParticle;
//
//	///////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	// �����ӵ���������������Ч
//	UPROPERTY(EditDefaultsOnly, Category = "PhysicalSound")
//	USoundBase* DirtSound;
//	UPROPERTY(EditDefaultsOnly, Category = "PhysicalSound")
//	USoundBase* GrassSound;
//	UPROPERTY(EditDefaultsOnly, Category = "PhysicalSound")
//	USoundBase* RockSound;
//	UPROPERTY(EditDefaultsOnly, Category = "PhysicalSound")
//	USoundBase* MetalSound;
//	UPROPERTY(EditDefaultsOnly, Category = "PhysicalSound")
//	USoundBase* WoodSound;
//	UPROPERTY(EditDefaultsOnly, Category = "PhysicalSound")
//	USoundBase* FleshSound;
//	UPROPERTY(EditDefaultsOnly, Category = "PhysicalSound")
//	USoundBase* HeadShotSound;
//
//	/////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	//��������
//	UPROPERTY(EditDefaultsOnly, Category = "Decal")
//	UMaterialInterface* BulletDecalMaterial;
//
//	//�˺�����
//	UPROPERTY(EditDefaultsOnly, Category = "Damage")
//	TSubclassOf<UDamageType> DamageTypeClass;
//
//	//��ֱ����
//	UPROPERTY(BlueprintReadOnly, Category = "Recoil")
//	float VerticalRecoil = 0.f;
//
//	//ˮƽ����
//	UPROPERTY(BlueprintReadOnly, Category = "Recoil")
//	float HorizontalRecoil = 0.f;
//
//	//����ģʽfalseΪ������trueΪ����
//	UPROPERTY(BlueprintReadOnly, Category = "Weapon")
//	bool ShootMode = true; 
//};
