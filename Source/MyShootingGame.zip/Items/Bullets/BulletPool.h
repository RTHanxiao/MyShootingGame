#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "BulletPool.generated.h"

class ABullet;

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))
class MYSHOOTINGGAME_API UBulletPool : public UActorComponent
{
	GENERATED_BODY()

public:
	UBulletPool();

	virtual void BeginPlay() override;

	/** ��ȡһ��δ������ӵ� */
	ABullet* GetBullet();

	/** �ӵ�����ʱ���� */
	void ReturnBullet(ABullet* Bullet);

	UPROPERTY(EditAnywhere)
	TSubclassOf<ABullet> BulletClass;

	UPROPERTY(EditAnywhere)
	int32 BulletCacheSize = 20;

	/** �ӵ����� */
	UPROPERTY()
	TArray<TObjectPtr<ABullet>> Pool;
};
