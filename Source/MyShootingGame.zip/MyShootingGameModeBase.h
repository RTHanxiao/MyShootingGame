// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "MyShootingGameModeBase.generated.h"

/**
 *
 */
UCLASS()
class MYSHOOTINGGAME_API AMyShootingGameModeBase : public AGameModeBase
{
	GENERATED_BODY()

public:
	AMyShootingGameModeBase();

	virtual void BeginPlay() override;

protected:

	// ==== Ԥ���ص�����ģʽ ==== //

	UPROPERTY(EditAnywhere, Category = "MSG|Hall")
	TSubclassOf<class APawn> HallPawnClass;

	UPROPERTY(EditAnywhere, Category = "MSG|Hall")
	TSubclassOf<class APlayerController> HallControllerClass;

	UPROPERTY(EditAnywhere, Category = "MSG|Hall")
	TSubclassOf<class AHUD> HallHUDClass;

	UPROPERTY(EditAnywhere, Category = "MSG|Fight")
	TSubclassOf<class APawn> FightPawnClass;

	UPROPERTY(EditAnywhere, Category = "MSG|Fight")
	TSubclassOf<class APlayerController> FightControllerClass;

	UPROPERTY(EditAnywhere, Category = "MSG|Fight")
	TSubclassOf<class AHUD> FightHUDClass;

public:

	/** ��ͼ�ɵ��ã����ݵ�ǰ�����л�ģʽ������ / ս���� */
	UFUNCTION(BlueprintCallable, Category = "MSG|WorldSwitch")
	void SwitchWorldMode(FName LoadedLevelName);

	/** �л��ɴ���ģʽ */
	void SetHallMode();

	/** �л���ս��ģʽ */
	void SetFightMode();
};
