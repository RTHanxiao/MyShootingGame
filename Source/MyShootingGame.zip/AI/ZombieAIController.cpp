// Fill out your copyright notice in the Description page of Project Settings.


#include "MyShootingGame/AI/ZombieAIController.h"
#include "Perception/AIPerceptionComponent.h"
#include "Perception/AISense_Sight.h"
#include "GameFramework/Character.h"

const FName AZombieAIController::BB_TargetPlayer(TEXT("Target_Player"));
const FName AZombieAIController::BB_IsAttacking(TEXT("IsAttacking"));
const FName AZombieAIController::BB_IsDead(TEXT("IsDead"));
const FName AZombieAIController::BB_LastKnownLocation(TEXT("LastKnowLocation"));
const FName AZombieAIController::BB_IsInSight(TEXT("IsInSight"));
const FName AZombieAIController::BB_TargetDistance(TEXT("TargetDistance"));
const FName AZombieAIController::BB_SenceState(TEXT("SenceState"));

AZombieAIController::AZombieAIController()
{
	BTComp = CreateDefaultSubobject<UBehaviorTreeComponent>(TEXT("BTComp"));
	BBComp = CreateDefaultSubobject<UBlackboardComponent>(TEXT("BBComp"));

	PerceptionComp = CreateDefaultSubobject<UAIPerceptionComponent>(TEXT("PerceptionComp"));
	SetPerceptionComponent(*PerceptionComp);

	SightConfig = CreateDefaultSubobject<UAISenseConfig_Sight>(TEXT("SightConfig"));
	SightConfig->SightRadius = 2000.f;
	SightConfig->LoseSightRadius = 2400.f;
	SightConfig->PeripheralVisionAngleDegrees = 70.f;
	SightConfig->SetMaxAge(2.0f);
	SightConfig->DetectionByAffiliation.bDetectEnemies = true;
	SightConfig->DetectionByAffiliation.bDetectNeutrals = true;
	SightConfig->DetectionByAffiliation.bDetectFriendlies = true;

	PerceptionComp->ConfigureSense(*SightConfig);
	PerceptionComp->SetDominantSense(UAISense_Sight::StaticClass());
	PerceptionComp->OnTargetPerceptionUpdated.AddDynamic(this, &AZombieAIController::OnPerceptionUpdated);
}

void AZombieAIController::OnPossess(APawn* InPawn)
{
	Super::OnPossess(InPawn);

	UBehaviorTree* BTAsset = BehaviorTreeAsset.Get();
	if (!BTAsset || !BTAsset->BlackboardAsset)
	{
		UE_LOG(LogTemp, Error, TEXT("[ZombieAIController] BehaviorTreeAsset or BlackboardAsset is null."));
		return;
	}

	// ��ʼ���ڰ壨UseBlackboard ����� Controller �� BlackboardComponent��
	UBlackboardComponent* BBD = BBComp.Get();
	if (!IsValid(BBD)) return;

	if (!UseBlackboard(BTAsset->BlackboardAsset, BBD))
	{
		UE_LOG(LogTemp, Error, TEXT("[ZombieAIController] UseBlackboard failed."));
		return;
	}

	RunBehaviorTree(BTAsset);
	if (BTComp)
	{
		BTComp->StartTree(*BTAsset);
	}

	// ��ѡ����ʼ��Ĭ��ֵ������������
	BBComp->SetValueAsBool(BB_IsInSight, false);
	BBComp->ClearValue(BB_TargetPlayer);
}

void AZombieAIController::OnPerceptionUpdated(AActor* Actor, FAIStimulus Stimulus)
{
	if (!BBComp || !Actor) return;

	const bool bSensed = Stimulus.WasSuccessfullySensed();
	AActor* CurTarget = Cast<AActor>(BBComp->GetValueAsObject(BB_TargetPlayer));

	if (bSensed)
	{
		// �������赱ǰĿ�꣬����״̬�����λ��
		BBComp->SetValueAsObject(BB_TargetPlayer, Actor);
		BBComp->SetValueAsBool(BB_IsInSight, true);

		// Seen ʱ�� Actor λ�ø��ȶ�
		BBComp->SetValueAsVector(BB_LastKnownLocation, Actor->GetActorLocation());
		BBComp->SetValueAsEnum(BB_SenceState, 0); // 0=Seeing
		return;
	}

	// ��ʧ��ֻ��������ǰĿ�ꡱ�Ķ�ʧ�������� Actor ����
	if (CurTarget && CurTarget != Actor)
	{
		return;
	}

	BBComp->SetValueAsBool(BB_IsInSight, false);
	BBComp->SetValueAsEnum(BB_SenceState, 1); // 1=Lost

	// �ؼ�����¼����ʧ�㡱
	// StimulusLocation ͨ������Ŀ����󱻸�֪����λ�ã�������ʱ�˻�Ϊ Actor λ��
	const FVector LostPos = Stimulus.StimulusLocation.IsNearlyZero()
		? Actor->GetActorLocation()
		: Stimulus.StimulusLocation;

	BBComp->SetValueAsVector(BB_LastKnownLocation, LostPos);
}