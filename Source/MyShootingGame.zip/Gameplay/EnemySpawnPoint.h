#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "EnemySpawnPoint.generated.h"

class UBoxComponent;

UCLASS()
class MYSHOOTINGGAME_API AEnemySpawnPoint : public AActor
{
	GENERATED_BODY()

public:
	AEnemySpawnPoint();

	UFUNCTION(BlueprintCallable, Category = "Spawn")
	FTransform GetSpawnTransform() const;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Spawn")
	TObjectPtr<UBoxComponent> SpawnArea;

	// ��� SpawnPoint ������Щ���򣨶�Զࣩ
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Spawn|Region", meta = (Categories = "Region"))
	FGameplayTagContainer BelongRegions;

	// ��ǰ�Ƿ񼤻�Ƿ���������ˢ�֣�
	UPROPERTY(BlueprintReadOnly, Category = "Spawn|Region")
	bool bActive = false;

protected:
	virtual void BeginPlay() override;

private:
	UPROPERTY()
	TObjectPtr<class AEnemyWaveDirector> CachedDirector;

	UFUNCTION()
	void HandleRegionActivated(FGameplayTag RegionId);

	UFUNCTION()
	void HandleRegionDeactivated(FGameplayTag RegionId);

	void RecalcActive(); // ���� BelongRegions �� Director ״̬ˢ�� bActive
};