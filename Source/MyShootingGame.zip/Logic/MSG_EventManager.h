// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "MSG_EventManager.generated.h"

//�л�����UI�ĵ���ί��
DECLARE_DELEGATE(SwitchGunUI)
//����׼������
DECLARE_DELEGATE_OneParam(ShowCrossHair,bool)
//����UI���ģʽ
DECLARE_DELEGATE_OneParam(SetShootModeUI, bool)
//����ʰȡ��UI
DECLARE_DELEGATE_OneParam(ShowItemUI,AActor* )
//��ʾ��ͷͼ��
DECLARE_DELEGATE(HeadShotEvent)
//��ʾ���з���
DECLARE_DELEGATE_OneParam(ShowHitFeedback, bool)
//��ɱ����
DECLARE_DELEGATE_OneParam(ShowKillFeedback, bool)
//��ɫ�ܻ�
DECLARE_DELEGATE(PlayerInjured)
//������ɫMesh�޸�
DECLARE_DELEGATE_OneParam(ChangeHallCharacterMesh, USkeletalMesh*)

/**
 * 
 */
UCLASS()
class MYSHOOTINGGAME_API UMSG_EventManager : public UObject
{
	GENERATED_BODY()
	
public:
		// Sets default values for this actor's properties
		//UMSG_EventManager();
		UFUNCTION(BlueprintCallable, Category = "EventManager")
		//void TriggerEvent(FName EventName);
		static UMSG_EventManager* GetEventManagerInstance();

		SwitchGunUI SwitchGunUIDelegate;
		ShowCrossHair ShowCrossHairDelegate;
		SetShootModeUI SetShootModeUIDelegate;
		ShowItemUI ShowItemUIDelegate;
		HeadShotEvent HeadShotEventDelegate;
		ShowHitFeedback ShowHitFeedbackDelegate;
		ShowKillFeedback ShowKillFeedbackDelegate;
		PlayerInjured PlayerInjuredDelegate;
		ChangeHallCharacterMesh ChangeHallCharacterMeshDelegate;
private:
	static UMSG_EventManager* Instance;
	
};
