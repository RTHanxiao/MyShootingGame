 // Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "MyCharacter.generated.h"

UCLASS()
class MYSHOOTINGGAME_API AMyCharacter : public ACharacter
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	AMyCharacter();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	//Actor������ս�˺�
	UPROPERTY(EditAnywhere,BlueprintReadOnly)
	float MeleeDamage = 20.f;

	UPROPERTY(BlueprintReadOnly)
	bool bDead = false;
	
	UPROPERTY(BlueprintReadOnly)
	float MaxHealth = 100.f;

	UPROPERTY(BlueprintReadOnly)
	float CurrentHealth = 100.f;

	//���˱���
	UPROPERTY(BlueprintReadOnly)
	float DamageReductionFactor = 1.f;

	UFUNCTION(BlueprintCallable)
	float GetHealthPercent() const
	{
		return CurrentHealth / MaxHealth;
	}

	UFUNCTION(BlueprintCallable)
	float GetMaxHealth() const
	{
		return MaxHealth;
	}

	UFUNCTION(BlueprintCallable)	
	float GetCurrentHealth() const
	{
		return CurrentHealth;
	}

	void Initilize();

	//��д���˺���
	virtual float TakeDamage(float DamageAmount, struct FDamageEvent const& DamageEvent, AController* EventInstigator, AActor* DamageCauser) override;

	//���õ�ǰѪ��
	void SetCurrentHealth(float NewHealth);

	//����������
	void Ragdoll();

	bool IsDead() const { return bDead; }

	virtual void PlayRandomMontageFromArray(const TArray<UAnimMontage*>& MontageArray);

	//��ս����
	UFUNCTION(BlueprintCallable)
	virtual void MeleeAttackCollision(AController* EventInstigator);

	//�ɹ�������
	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<AMyCharacter> AttackableTargetClass;

	//��һ�����ŵĹ�������
	int32 LastIndex;
};
