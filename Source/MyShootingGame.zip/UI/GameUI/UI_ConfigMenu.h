#pragma once

#include "CoreMinimal.h"
#include "MyShootingGame/UI/MSG_UserWidgetBase.h"
#include "UI_ConfigMenu.generated.h"

class UButton;
class UTextBlock;
class UWidgetAnimation;

UCLASS()
class MYSHOOTINGGAME_API UUI_ConfigMenu : public UMSG_UserWidgetBase
{
	GENERATED_BODY()

protected:
	virtual void NativeConstruct() override;

public:
	// ��ť
	UPROPERTY(meta = (BindWidget))
	UButton* Btn_Apply;

	UPROPERTY(meta = (BindWidget))
	UButton* Btn_Back;

	// Apply �ı�
	UPROPERTY(meta = (BindWidget))
	UTextBlock* Tb_Apply;

	// Apply ��ͣ�Ŵ󶯻�
	UPROPERTY(Transient, meta = (BindWidgetAnim))
	UWidgetAnimation* ApplyHoverAnim;

	// �¼�
	UFUNCTION()
	void BtnBackClicked();

	UFUNCTION()
	void BtnApplyHovered();

	UFUNCTION()
	void BtnApplyUnHovered();

	UFUNCTION()
	void BtnApplyClicked();

protected:
	// ͨ�ö������ţ���ͣ true ���š��뿪 false ����
	void PlayHoverAnim(UWidgetAnimation* Anim, bool bHover);
};
