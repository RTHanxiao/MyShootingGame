// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "MyShootingGame/UI/MSG_UserWidgetBase.h"
#include "../../../../../../../Source/Runtime/UMG/Public/Components/Image.h"
#include "UI_FightMain.generated.h"

class UWidgetSwitcher;
class UInv_InfoMessage;
/** 
 */
UCLASS()
class MYSHOOTINGGAME_API UUI_FightMain : public UMSG_UserWidgetBase
{
	GENERATED_BODY()
	
	virtual void NativeConstruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;
	virtual void NativeOnInitialized() override;

public:

	UPROPERTY(meta = (BindWidget))
	UWidgetSwitcher* WeaponInfoSwitcher;
	UPROPERTY(meta = (BindWidget))
	UImage* WeaponIcon;

	UPROPERTY(meta = (BindWidget))
	UImage* CrossHairUP;
	UPROPERTY(meta = (BindWidget))
	UImage* CrossHairDown;
	UPROPERTY(meta = (BindWidget))
	UImage* CrossHairLeft;
	UPROPERTY(meta = (BindWidget))
	UImage* CrossHairRight;
	UPROPERTY(meta = (BindWidget))
	UImage* CrossHairCenter;

	//��Ϣ��ʾUI
	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UInv_InfoMessage> InfoMessageUI;
	UFUNCTION()
	void OnNoRoom();

	//����׼����ʾ״̬
	void SetCrossHairVisibility(bool bIsVisible);

	//�޸�������Ϣ��ʾ
	void ChangWeaponInfo();
	
	//�������ģʽUI
	UFUNCTION(BlueprintImplementableEvent)
	void UpdateShootModeUI(bool bIsAuto);

	//���ñ�ͷ��־��ʾ״̬
	UFUNCTION(BlueprintImplementableEvent)
	void PlayHeadShotUIAnim();

	//���з�����ʾ
	UFUNCTION(BlueprintImplementableEvent)
	void ShowHitFeedbackUI(bool IsHeadShot);
	//��ɱ����
	UFUNCTION(BlueprintImplementableEvent)
	void ShowKillFeedbackUI(bool IsHeadShot);
	//��ɫ�ܻ�����
	UFUNCTION(BlueprintImplementableEvent)
	void ShowPlayerInjuredUI();

};
